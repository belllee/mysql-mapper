<template>
  <div id="app">
    <el-container direction="vertical">
      <el-header>Header</el-header>
      <el-container>
        <el-main>
          <mysql class="mysql-box" ></mysql>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import Mysql from './components/mysql'
window.MYSQL = {}
export default {
  name: 'mysql-mapper',
  components: {
    Mysql
  },
  data () {
    return {
      tableData: []
    }
  }
}
</script>

<style>
  .el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
  }
  
  .el-aside {
    color: #333;
  }
  /* .mysql-box{
    margin-top: 20px;
  } */
</style>
