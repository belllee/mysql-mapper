import genHashcode from './hashcode'
const os = require('os')
const DATA_TYPE = {
  int: 'Long',
  tinyint: 'Integer',
  smallint: 'Integer',
  mediumint: 'Integer',
  integer: 'Long',
  bigint: 'Long',
  bit: 'bit',
  double: '',
  float: '',
  decaimal: '',
  numeric: '',

  char: 'String',
  nchar: 'String',
  varchar: 'String',
  nvarchar: 'String',
  text: 'String',
  mediumtext: 'String',
  longtext: 'String',
  tinytext: 'String',

  date: 'Date',
  time: 'Date',
  year: 'Date',
  datetime: 'Date',
  timestamp: 'Date',

  real: 'boolean',
  enum: 'String'
}

const SUBFIX = {
  'Entity': '.java',
  'Mapper': '.xml',
  'Dao': '.java',
  'DaoImpl': '.java',
  'Service': '.java',
  'ServiceImpl': '.java'
}
const ORM_TYPE_MYBATIS = 'Mybatis'
class CodeService {
  constructor (tableName, columns, options) {
    this.tableName = tableName
    this.columns = columns
    this.options = options
    this.init()
  }
  init () {
    if (!this.options) {
      return false
    }
    console.log('options', this.options)
    let dao = this.options.ormType === ORM_TYPE_MYBATIS ? 'Dao' : 'Repository'
    this.entityName = this.formatName(this.tableName)
    this.daoName = this.entityName + dao
    this.daoimplName = this.entityName + 'DaoImpl'
    this.serviceName = this.entityName + 'Service'
    this.serviceimplName = this.entityName + 'ServiceImpl'
    this.mapperName = this.entityName + 'Mapper'
    this.entityPackage = this.options.package + '.entity'
    this.daoPackage = this.options.package + '.' + dao.toLocaleLowerCase()
    this.daoImplPackage = this.options.package + '.' + dao.toLocaleLowerCase() + '.impl'
    this.servicePackage = this.options.package + '.service'
    this.serviceImplPackage = this.options.package + '.service.impl'
    this.mapperPackage = this.options.package + '.mapper'

    this.newColumns = []
    this.ignores = []
    if (this.options.ignore) {
      this.ignores = this.options.ignore.replace('，', ',').split(',')
    }
    for (let i = 0, c; (c = this.columns[i]);i++) {
      let nameSmall = this.formatName(c.column_name, true)
      let newColumn = {
        name: this.formatName(c.column_name),
        nameSmall: nameSmall,
        type: DATA_TYPE[c.data_type],
        originName: c.column_name,
        isNeedDefine: c.column_name !== nameSmall,
        isLob: c.data_type === 'longtext',
        isKey: c.column_key === 'PRI'
      }
      this.newColumns.push(newColumn)
    }
  }

  formatName (str, isSmall) {
    if (!str) {
      return ''
    }
    str = str.replace('-', '_')
    let array = str.split('_')
    let begin = 0
    if (isSmall) {
      begin = 1
      array[0] = array[0].toLowerCase()
    }
    for (let i = begin, t; (t = array[i]); i++) {
      if (t.length > 1) {
        array[i] = t.substring(0, 1).toUpperCase() + t.substring(1).toLowerCase()
      } else if (t.length === 1) {
        array[i] = t.toUpperCase()
      }
    }
    return array.join('')
  }
  genHash () {
    return genHashcode(this.options.package + '.entity.' + this.entityName) + 'L'
  }
  genFileName (type) {
    return this[type.toLowerCase() + 'Name'] + SUBFIX[type]
  }
  genCode (type) {
    return this['gen' + type]()
  }
  genDao () {
    let arr = []
    arr.push('package ' + this.daoPackage + ';')
    arr.push('')
    arr.push('import ' + this.options.daoPackage + '.' + this.options.dao + ';')
    arr.push('import ' + this.entityPackage + '.' + this.entityName + ';')
    if (this.options.ormType === 'Mybatis') {
      arr.push('import org.apache.ibatis.annotations.Mapper;')
    }

    arr.push('')
    arr.push('/**')
    arr.push('* @author mysql-mapper')
    arr.push('*/')
    arr.push('')
    if (this.options.ormType === 'Mybatis') {
      arr.push('@Mapper')
    }
    arr.push('public interface ' + this.daoName + ' extends ' + this.options.dao + '<' + this.entityName + ', ' + this.options.keyType + '> {')
    arr.push('')
    arr.push('}')
    return arr.join(os.EOL)
  }
  genServiceImpl () {
    let arr = []
    arr.push('package ' + this.serviceImplPackage + ';')
    arr.push('')
    this.options.serviceImpl && arr.push('import ' + this.options.serviceImplPackage + '.' + this.options.serviceImpl + ';')
    arr.push('import ' + this.servicePackage + '.' + this.serviceName + ';')
    arr.push('import ' + this.daoPackage + '.' + this.daoName + ';')
    arr.push('import ' + this.entityPackage + '.' + this.entityName + ';')
    arr.push('import org.springframework.beans.factory.annotation.Autowired;')
    arr.push('import org.springframework.stereotype.Service;')
    arr.push('')
    arr.push('/**')
    arr.push('* @author mysql-mapper')
    arr.push('*/')
    arr.push('')
    arr.push('@Service')
    let baseSerivice = this.options.serviceImpl ? ' extends ' + this.options.serviceImpl + '<' + this.entityName + ', ' + this.options.keyType + '>' : ''
    arr.push('public class ' + this.serviceimplName + baseSerivice + ' implements ' + this.serviceName + ' {')
    arr.push('')
    arr.push('    @Autowired')
    arr.push('    ' + this.daoName + ' repository;')
    arr.push('')
    arr.push('    @Autowired')
    arr.push('    void setRepository(' + this.daoName + ' repository){')
    arr.push('        this.repository = repository;')
    arr.push('    }')

    arr.push('}')
    return arr.join(os.EOL)
  }
  genService () {
    let arr = []
    arr.push('package ' + this.servicePackage + ';')
    arr.push('')
    this.options.service && arr.push('import ' + this.options.servicePackage + '.' + this.options.service + ';')
    arr.push('import ' + this.daoPackage + '.' + this.daoName + ';')
    arr.push('import ' + this.entityPackage + '.' + this.entityName + ';')
    arr.push('')
    arr.push('/**')
    arr.push('* @author mysql-mapper')
    arr.push('*/')
    arr.push('')
    let baseSerivice = this.options.service ? ' extends ' + this.options.service + '<' + this.entityName + ', ' + this.options.keyType + '>' : ''
    arr.push('public interface ' + this.serviceName + baseSerivice + ' {')
    arr.push('')
    arr.push('}')
    return arr.join(os.EOL)
  }
  genDaoImpl () {
    let arr = []
    arr.push('package ' + this.daoImplPackage + ';')
    arr.push('')
    this.options.daoImpl && arr.push('import ' + this.options.daoImplPackage + '.' + this.options.daoImpl + ';')
    arr.push('import ' + this.daoPackage + '.' + this.daoName + ';')
    arr.push('import ' + this.entityPackage + '.' + this.entityName + ';')
    arr.push('import org.springframework.stereotype.Repository;')
    arr.push('')
    arr.push('/**')
    arr.push('* @author mysql-mapper')
    arr.push('*/')
    arr.push('')
    arr.push('@Repository')
    let baseDao = this.options.daoImpl ? ' extends ' + this.options.daoImpl + '<' + this.entityName + ', ' + this.options.keyType + '>' : ''
    arr.push('public class ' + this.daoimplName + baseDao + ' implements ' + this.daoName + ' {')
    arr.push('')
    arr.push('}')
    return arr.join(os.EOL)
  }
  genEntity () {
    let arr = []
    arr.push('package ' + this.entityPackage + ';')
    arr.push('')
    arr.push('import ' + this.options.entityPackage + '.' + this.options.entity + ';')
    arr.push('import java.io.Serializable;')
    if (this.options.ormType !== ORM_TYPE_MYBATIS) {
      arr.push('import javax.persistence.*;')
    }
    arr.push('')
    arr.push('/**')
    arr.push('* @author mysql-mapper')
    arr.push('*/')
    arr.push('')
    arr.push('@Entity')
    arr.push('@Table(name="' + this.tableName + '")')
    arr.push('public class ' + this.entityName + ' extends ' + this.options.entity + ' implements Serializable {')
    arr.push('')
    arr.push('    private static final long serialVersionUID = ' + this.genHash() + ';')
    arr.push('')
    for (let i = 0, c; (c = this.newColumns[i]);i++) {
      if (this.ignores.includes(c.originName)) {
        continue
      }
      arr.push('    private ' + c.type + ' ' + c.nameSmall + ';')
    }
    arr.push('')
    for (let i = 0, c; (c = this.newColumns[i]);i++) {
      if (this.ignores.includes(c.originName)) {
        continue
      }
      if (this.options.ormType !== ORM_TYPE_MYBATIS) {
        if (c.isLob) {
          arr.push('    @Lob')
        }
        if (c.isNeedDefine) {
          arr.push('    @Column(name = "' + c.originName + '")')
        }
      }
      arr.push('    public ' + c.type + ' get' + c.name + '() {')
      arr.push('        return ' + c.nameSmall + ';')
      arr.push('    }')
      arr.push('    public void set' + c.name + '(' + c.type + ' ' + c.nameSmall + ') {')
      arr.push('        this.' + c.nameSmall + ' = ' + c.nameSmall + ';')
      arr.push('    }')
      arr.push('')
    }

    arr.push('}')
    return arr.join(os.EOL)
  }

  genMapper () {
    let arr = []
    let entity = this.entityPackage + '.' + this.entityName
    let len = this.newColumns.length - 1
    arr.push('<?xml version="1.0" encoding="UTF-8"?>')
    arr.push('<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">')
    arr.push('')
    arr.push('<mapper namespace="' + entity + '">')
    arr.push('<resultMap id="BaseResultMap" type="' + entity + '">')
    for (let i = 0, c; (c = this.newColumns[i]);i++) {
      if (c.isKey) {
        arr.push('    <id property="' + c.nameSmall + '" column="' + c.originName + '"/>')
      } else {
        arr.push('    <result property="' + c.nameSmall + '" column="' + c.originName + '"/>')
      }
    }
    arr.push('</resultMap>')
    arr.push('')
    arr.push('<sql id="Base_Column_List">')
    for (let i = 0; i < len; i++) {
      arr.push('    ' + this.newColumns[i].originName + ',')
    }
    arr.push('    ' + this.newColumns[len].originName)
    arr.push('</sql>')
    arr.push('<sql id="Where_Clause_Id">')
    for (let i = 0, c; (c = this.newColumns[i]);i++) {
      if (c.isKey) {
        arr.push('    AND ' + c.originName + ' = #{' + c.originName + '}')
      }
    }
    arr.push('</sql>')
    arr.push('')
    arr.push('<sql id="Where_Clause_Normal">')
    for (let i = 0, c; (c = this.newColumns[i]);i++) {
      if (!c.isKey) {
        arr.push('    <if test="' + c.nameSmall + ' != null">')
        arr.push('        AND ' + c.originName + ' = #{' + c.originName + '}')
        arr.push('    </if>')
      }
    }
    arr.push('</sql>')
    arr.push('')
    arr.push('<!--根据主键查询 -->')
    arr.push('<select id="selectByPrimaryKey" parameterType="java.lang.' + this.options.keyType + '" resultMap="BaseResultMap">')
    arr.push('    SELECT')
    arr.push('    <include refid="Base_Column_List"/>')
    arr.push('        FROM ' + this.tableName)
    arr.push('    <where>')
    arr.push('        <include refid="Where_Clause_Id"/>')
    arr.push('    </where>')
    arr.push('</select>')
    arr.push('')
    arr.push('<!--根据主键删除 -->')
    arr.push('<delete id="deleteByPrimaryKey" parameterType="java.lang.' + this.options.keyType + '">')
    arr.push('    DELETE FROM ' + this.tableName)
    arr.push('    <where>')
    arr.push('        <include refid="Where_Clause_Id"/>')
    arr.push('    </where>')
    arr.push('</delete>')
    arr.push('')
    arr.push('<!--新增保存 -->')
    arr.push('<insert id="insert" parameterType="' + entity + '" keyProperty="id">')
    arr.push('    INSERT INTO ' + this.tableName)
    arr.push('    (')
    arr.push('        <include refid="Base_Column_List"/>')
    arr.push('    )')
    arr.push('    VALUES(')
    for (let i = 0; i < len; i++) {
      arr.push('        #{' + this.newColumns[i].nameSmall + '},')
    }
    arr.push('        #{' + this.newColumns[len].nameSmall + '}')
    arr.push('    )')
    arr.push('</insert>')
    arr.push('')
    arr.push('<!--选择性保存-->')
    arr.push('<insert id="insertSelective" parameterType="' + entity + '">')
    arr.push('    INSERT INTO ' + this.tableName)
    arr.push('    <trim prefix="(" suffix=")" suffixOverrides=",">')
    for (let i = 0; i < len; i++) {
      arr.push('        <if test="' + this.newColumns[i].nameSmall + ' !=null">')
      arr.push('            ' + this.newColumns[i].originName + ',')
      arr.push('        </if>')
    }
    arr.push('        <if test="' + this.newColumns[len].nameSmall + ' !=null">')
    arr.push('            ' + this.newColumns[len].originName)
    arr.push('        </if>')
    arr.push('    </trim>')
    arr.push('    <trim prefix="values (" suffix=")" suffixOverrides=",">')
    for (let i = 0; i < len; i++) {
      arr.push('        <if test="' + this.newColumns[i].nameSmall + ' !=null">')
      arr.push('            #{' + this.newColumns[i].nameSmall + '},')
      arr.push('        </if>')
    }
    arr.push('        <if test="' + this.newColumns[len].nameSmall + ' !=null">')
    arr.push('            #{' + this.newColumns[len].nameSmall + '}')
    arr.push('        </if>')
    arr.push('    </trim>')
    arr.push('</insert>')
    arr.push('')
    arr.push('<!--根据主键选择性更新部分字段 -->')
    arr.push('<update id="updateByPrimaryKeySelective" parameterType="' + entity + '">')
    arr.push('    UPDATE ' + this.tableName)
    arr.push('    <set>')
    for (let i = 0; i < len; i++) {
      arr.push('        <if test="' + this.newColumns[i].nameSmall + ' !=null">')
      arr.push('            ' + this.newColumns[len].originName + ' = #{' + this.newColumns[i].nameSmall + '},')
      arr.push('        </if>')
    }
    arr.push('        <if test="' + this.newColumns[len].nameSmall + ' !=null">')
    arr.push('            ' + this.newColumns[len].originName + ' = #{' + this.newColumns[len].nameSmall + '}')
    arr.push('        </if>')
    arr.push('    </set>')
    arr.push('    <where>')
    arr.push('        <include refid="Where_Clause_Id"/>')
    arr.push('    </where>')
    arr.push('</update>')
    arr.push('')
    // arr.push('<!--选择性查询-->')
    // arr.push('<select id="listAllByParam" parameterType="java.util.Map" resultMap="BaseResultMap">')
    // arr.push('    SELECT')
    // arr.push('    <include refid="Base_Column_List"/>')
    // arr.push('    FROM ' + this.tableName)
    // arr.push('    <where>')
    // for (let i = 0; i < len; i++) {
    //   arr.push('        <if test="' + this.newColumns[i].nameSmall + ' !=null">')
    //   arr.push('            ' + this.newColumns[len].originName + ' = #{' + this.newColumns[i].nameSmall + '},')
    //   arr.push('        </if>')
    // }
    // arr.push('        <if test="' + this.newColumns[len].nameSmall + ' !=null">')
    // arr.push('            ' + this.newColumns[len].originName + ' = #{' + this.newColumns[len].nameSmall + '}')
    // arr.push('        </if>')
    // arr.push('    </where>')
    // arr.push('</select>')
    // arr.push('')
    arr.push('<!--选择性更新-->')
    arr.push('<update id="updateByMap" parameterType="java.util.Map">')
    arr.push('    UPDATE')
    arr.push('    ' + this.tableName)
    arr.push('    <set>')
    for (let i = 0; i < len; i++) {
      arr.push('        <if test="' + this.newColumns[i].nameSmall + ' !=null">')
      arr.push('            ' + this.newColumns[len].originName + ' = #{' + this.newColumns[i].nameSmall + '},')
      arr.push('        </if>')
    }
    arr.push('        <if test="' + this.newColumns[len].nameSmall + ' !=null">')
    arr.push('            ' + this.newColumns[len].originName + ' = #{' + this.newColumns[len].nameSmall + '}')
    arr.push('        </if>')
    arr.push('    </set>')
    arr.push('    <where>')
    for (let i = 0; i < len; i++) {
      arr.push('        <if test="' + this.newColumns[i].nameSmall + ' !=null">')
      arr.push('            AND ' + this.newColumns[len].originName + ' = #{' + this.newColumns[i].nameSmall + '},')
      arr.push('        </if>')
    }
    arr.push('        <if test="' + this.newColumns[len].nameSmall + ' !=null">')
    arr.push('            AND ' + this.newColumns[len].originName + ' = #{' + this.newColumns[len].nameSmall + '}')
    arr.push('        </if>')
    arr.push('    </where>')
    arr.push(' </update>')
    arr.push('')
    arr.push('<!--选择性查询-->')
    arr.push('<select id="listDatas" parameterType="java.util.Map" resultMap="BaseResultMap">')
    arr.push('    SELECT')
    arr.push('    <include refid="Base_Column_List"/>')
    arr.push('    FROM ' + this.tableName)
    arr.push('    <where>')
    arr.push('        <include refid="Where_Clause_Normal"/>')
    arr.push('    </where>')
    arr.push('</select>')
    arr.push('')
    arr.push('<!--选择性统计总数-->')
    arr.push('<select id="countDatas" resultType="java.lang.Integer">')
    arr.push('    SELECT count(1)')
    arr.push('    FROM ' + this.tableName)
    arr.push('    <where>')
    arr.push('        <include refid="Where_Clause_Normal"/>')
    arr.push('    </where>')
    arr.push('</select>')
    arr.push('</mapper>')
    return arr.join(os.EOL)
  }
}
export default CodeService
