<template>
<el-row :gutter="20">
  <el-col :span="5">
    <h3>Mysql信息</h3>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px">
      <el-form-item label="Host" prop="host">
        <el-input v-model="form.host"></el-input>
      </el-form-item>
      <el-form-item label="Port" prop="port">
        <el-input v-model="form.port"></el-input>
      </el-form-item>
      <el-form-item label="Database" prop="database">
        <el-input v-model="form.database"></el-input>
      </el-form-item>
      <el-form-item label="User" prop="user">
        <el-input v-model="form.user"></el-input>
      </el-form-item>
      <el-form-item label="Passwd" prop="password">
        <el-input v-model="form.password"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">连接</el-button>
        <el-button @click="close">关闭</el-button>
      </el-form-item>
    </el-form>
  </el-col>
  <el-col :span="5">
    <div class="">连接状态：{{state}}</div>
    <div class="">数据表信息：</div>
    <div class="tables">
      <el-table
        ref="table"
        :data="tableList"
        stripe
        style="width: 100%"
        @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="35">
        </el-table-column>
        <el-table-column min-width="120" label="表名">
          <template slot-scope="scope" :title="scope.row.name">
            {{scope.row.name}}
          </template>
        </el-table-column>
      </el-table>
    </div>
  </el-col>
  <el-col :span="14">
    <div>
    <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
      <div style="margin: 15px 0;"></div>
      <el-checkbox-group v-model="checkedTargets" @change="handleCheckedTargetChange">
        <el-checkbox v-for="t in targets" :label="t" :key="t">{{t}}</el-checkbox>
      </el-checkbox-group>
    </div>
    <div class="gen-para">
      <el-form ref="form" :model="mapper" :rules="mrules" label-width="120px">
        <el-row :gutter="5">
          <el-col :span="12">
            <el-form-item label="导出目录" prop="path">
              <el-input type='file' ref="outPath" webkitdirectory @change="handlePathChange"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="package全称" prop="package">
              <el-input v-model="mapper.package" placeholder="com.my.app"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="12">
            <el-form-item label="entity基类" prop="entity">
              <el-input v-model="mapper.entity" placeholder="BaseEntity"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="基类包名称" prop="entityPackage">
              <el-input v-model="mapper.entityPackage" placeholder="com.my.app.entity.BaseEntity"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="12">
            <el-form-item label="主键类型">
              <el-select v-model="mapper.keyType" placeholder="请选择主键类型">
                <el-option label="String" value="String"></el-option>
                <el-option label="Long" value="Long"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="忽略字段" prop="ignore">
              <el-input v-model="mapper.ignore" placeholder="id,create_time,modify_time"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="12">
            <el-form-item label="dao基类" prop="dao">
              <el-input v-model="mapper.dao" placeholder="BaseDao"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="基类包名称" prop="daoPackage">
              <el-input v-model="mapper.daoPackage" placeholder="com.my.app.dao.BaseDao"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="12">
            <el-form-item label="daoImpl基类" prop="daoImpl">
              <el-input v-model="mapper.daoImpl" placeholder="BaseDaoImpl"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="基类包名称" prop="daoImplPackage">
              <el-input v-model="mapper.daoImplPackage" placeholder="com.my.app.dao.impl.BaseDaoImpl"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="12">
            <el-form-item label="service基类" prop="service">
              <el-input v-model="mapper.service" placeholder="BaseService"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="基类包名称" prop="servicePackage">
              <el-input v-model="mapper.servicePackage" placeholder="com.my.app.service.BaseService"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="12">
            <el-form-item label="serviceImpl基类" prop="serviceImpl">
              <el-input v-model="mapper.serviceImpl" placeholder="BaseServiceImpl"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="基类包名称" prop="serviceImplPackage">
              <el-input v-model="mapper.serviceImplPackage" placeholder="com.my.app.service.impl.BaseServiceImpl"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="5">
          <el-col :span="12">
            <el-form-item label="ORM类型">
              <el-select v-model="mapper.ormType" placeholder="请选择ORM类型">
                <el-option label="Mybatis" value="Mybatis"></el-option>
                <el-option label="JPA" value="JPA"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
          </el-col>
        </el-row>
        <el-form-item>
          <el-button type="primary" @click="doGenerate">开始生成</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div>
      <h4>执行记录：</h4>
      <textarea name="message" id="" style="width:100%" rows="10" v-model="message"></textarea>
    </div>
  </el-col>
</el-row>
</template>
<script>
import file from './file'
import CodeService from '@/components/code'
import storage from '@/components/storage'

const mysql = require('mysql')
const path = require('path')
const DB_CONFIG = 'MYSQL-MAPPER-DB'
const MAPPER_CONFIG = 'MYSQL-MAPPER-CONFIG'
export default {
  data () {
    return {
      state: '未连接',
      message: '',
      tableList: [],
      selectable: [],
      targets: ['Entity', 'Mapper', 'Dao', 'Service'],
      checkAll: false,
      checkedTargets: [],
      isIndeterminate: true,
      form: {
        host: '10.89.168.135',
        port: '3306',
        database: 'event_old',
        user: 'wxcop',
        password: 'wxcop',
        multipleStatements: true
        // ssl: {
        //   // DO NOT DO THIS set up your ca correctly to trust the connection
        //   rejectUnauthorized: false
        // }
      },
      rules: {
        host: [
          { required: true, message: '请输入主机地址', trigger: 'blur' }
        ],
        port: [
          { required: true, message: '请输入端口', trigger: 'blur' }
        ],
        database: [
          { required: true, message: '请输入数据库名', trigger: 'blur' }
        ],
        user: [
          { required: true, message: '请输入用户名', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ]
      },
      mapper: {
        package: 'com.abc.test',
        entity: 'BaseEntity',
        entityPackage: 'com.abc.test.entity',
        keyType: 'String',
        ormType: 'Mybatis',
        ignore: 'id,create_time,modify_time',
        path: '',
        dao: 'BaseDao',
        daoPackage: 'com.abc.test.dao',
        daoImpl: 'BaseDaoImpl',
        daoImplPackage: 'com.abc.test.dao.impl',
        service: 'BaseService',
        servicePackage: 'com.abc.test.service',
        serviceImpl: 'BaseServiceImpl',
        serviceImplPackage: 'com.abc.test.service.impl'
      },
      mrules: {

      }
    }
  },
  created () {
    let db = storage.read(DB_CONFIG)
    if (db) {
      this.form = db
    }
    let mapper = storage.read(MAPPER_CONFIG)
    if (mapper) {
      this.mapper = mapper
    }
  },
  methods: {
    addMessage (message) {
      this.message = message + '\n' + this.message
    },
    onSubmit () {
      storage.save(DB_CONFIG, this.form)
      const me = this
      var connection = mysql.createConnection(this.form)
      connection.connect(function (err) {
        if (err) {
          me.addMessage('数据库连接失败：' + err.message)
          console.error('error connecting: ' + err.stack)
          return
        }
        me.addMessage('数据库连接成功')
        window.MYSQL['connection'] = connection
        console.log('connected as id ' + connection.threadId)
        let query = "select table_name AS name from information_schema.tables where table_schema='" + me.form.database + "' and table_type='base table';"
        console.log('query', query)
        connection.query(query, function (error, results, fields) {
          if (error) {
            me.addMessage('查询数据表信息成功，共有' + error.message + '个表')
            console.error(error)
            return
          }
          me.tableList = results
          me.addMessage('查询数据表信息成功，共有' + results.length + '个表')
          console.log(results, fields)
          // connected!
        })
      })
    },
    close () {
      window.MYSQL.connection && window.MYSQL.connection.destroy()
    },
    handleSelectionChange (val) {
      this.selectable = val
    },
    handleCheckAllChange (val) {
      this.checkedTargets = val ? this.targets : []
      this.isIndeterminate = false
    },
    handleCheckedTargetChange (value) {
      this.checkedTargets = value
      let checkedCount = value.length
      this.checkAll = checkedCount === this.targets.length
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.targets.length
    },
    handlePathChange () {
      let input = this.$refs.outPath.$el.querySelector('input')
      input && input.files && input.files[0] && input.files[0].path && (this.mapper.path = input.files[0].path)
    },
    doGenerate () {
      if (this.selectable.length === 0) {
        this.addMessage('请先选择要处理的表')
        this.$message.error('请先选择要处理的表')
        return
      }

      if (!this.mapper.path) {
        this.addMessage('导出目录不能为空')
        this.$message.error('导出目录不能为空')
        return
      }
      storage.save(MAPPER_CONFIG, this.mapper)
      // console.log(this.mapper, this.selectable)
      for (let i = 0, t; (t = this.selectable[i]); i++) {
        this.handleOneTable(t.name)
      }
    },
    writeFile (path, filename, data) {
      let me = this
      return new Promise((resolve, reject) => {
        file.initFolder(path).then(() => {
          me.addMessage('开始构造文件：' + path + filename)
          file.writeData(path + filename, data).then(e => {
            resolve()
            me.addMessage('写文件(' + path + filename + ')成功')
          }).catch(e => {
            resolve()
            me.addMessage('写文件(' + path + filename + ')失败：' + e.message)
          })
        }).catch(e => {
          resolve()
          me.addMessage('初始化目录(' + path + filename + ')失败：' + e.message)
        })
      })
    },
    getOutPath (p) {
      let folder = ''
      if (p === 'Entity') {
        folder = 'entity'
      } else if (p === 'Service') {
        folder = 'service'
      } else if (p === 'Mapper') {
        folder = 'mapper'
      } else if (p === 'Dao') {
        folder = this.mapper.ormType === 'Mybatis' ? 'dao' : 'repository'
      } else {
        return ''
      }
      return this.mapper.path + path.sep + folder + path.sep
    },
    handleOneTable (table) {
      this.addMessage('开始查询表(' + table + ')的字段')
      const me = this
      let query = "USE information_schema ;SELECT column_name,data_type,column_default,column_type,column_key FROM columns WHERE table_name='" + table + "' AND table_schema='" + this.form.database + "';"
      new Promise((resolve, reject) => {
        window.MYSQL.connection && window.MYSQL.connection.query(query, function (error, results, fields) {
          if (error) {
            me.addMessage('查询数据表的字段定义失败：' + error.message)
            console.error(error)
            reject(error)
            return
          }
          me.addMessage('查询数据表的字段定义成功，共有' + results[1].length + '个字段')
          console.log(results, fields)
          resolve(results)
        })
      }).then((results) => {
        let column = results[1]
        let code = new CodeService(table, column, me.mapper)
        for (let i = 0, t; (t = this.checkedTargets[i]); i++) {
          if (t === 'Mapper' && this.mapper.ormType !== 'Mybatis') {
            me.addMessage('JPA模式无需构造Mapper文件')
            continue
          }

          let folerPath = this.getOutPath(t)
          this.writeFile(folerPath, code.genFileName(t), code.genCode(t)).then(() => {
            if (t === 'Service' || (t === 'Dao' && this.mapper.ormType === 'Mybatis')) {
              this.writeFile(folerPath + 'impl' + path.sep, code.genFileName(t + 'Impl'), code.genCode(t + 'Impl'))
            }
          })
        }
      })
    }
  }
}
</script>
<style>
.gen-para{
  margin-top: 20px;
  width: 100%;
}
</style>
