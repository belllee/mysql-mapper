
let fs = require('fs')

class FileService {
  writeData (file, data) {
    return new Promise((resolve, reject) => {
      let wdata = Buffer.from(data)

      fs.writeFile(file, wdata, function (err) {
        if (err) {
          console.error(err)
          return reject(err)
        } else {
          console.log('写入成功')
          resolve()
        }
      })
    })
  }

  initFolder (path) {
    return new Promise((resolve, reject) => {
      fs.stat(path, (error, stats) => {
        if (error) {
          console.error(error)
          fs.mkdir(path, function (err) {
            if (err) {
              console.error('mkdir', err)
              return reject(err)
            }
            console.log('目录创建成功。', path)
            resolve()
          })
          return
        }
        console.log(stats)
        if (stats.isDirectory()) {
          resolve()
        }
      })
    })
  }
}
export default new FileService()
