import CodeService from '@/components/code'
import genHashcode from '@/components/hashcode'
describe('codeService', () => {
  it('genHashcode', () => {
    let a = genHashcode('a')
    let b = genHashcode('a')
    console.log('genHashcode A=', a)
    console.log('genHashcode B=', b)
    expect(a).not.to.eq(b)
  })

  it('format', () => {
    let code = new CodeService()
    expect(code.formatName('test_table')).to.eq('TestTable')
    expect(code.formatName('test-table_haha')).to.eq('TestTableHaha')
    expect(code.formatName('test_table', true)).to.eq('testTable')
    expect(code.formatName('test-table_haha', true)).to.eq('testTableHaha')
  })
  it('init entityName', () => {
    let code = new CodeService('test_table')
    expect(code.entityName).to.eq('TestTable')
    code = new CodeService('test-table_haha')
    expect(code.entityName).to.eq('TestTableHaha')
  })

  it('test', () => {
    let code = new CodeService('test_table', [], {
      package: 'com.abc.my',
      entity: 'BaseEntity',
      entityPackage: 'com.abc.my.entity',
      keyType: 'String',
      ignor: '',
      path: '',
      dao: '',
      daoPackage: '',
      service: '',
      servicePackage: ''
    })
    console.log(code.genEntity())
  })
})
